﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstractclass_feb2
{
    abstract class a
    {
        public void studentsname()
        {
            Console.WriteLine("I am vivek yadav");
        }
    }
    class b
    {

    }
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
