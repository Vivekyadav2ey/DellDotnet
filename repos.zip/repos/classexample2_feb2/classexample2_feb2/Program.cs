﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classexample2_feb2
{
    //what is a inheritance is
    class Automobiles
    {
        public void spareparts()
        {
            //blank
            string s="hi"
            Console.WriteLine("please enter the spare parts");
            Console.ReadLine();
        }
    }
    class cars:Automobiles
    {

    }

    class Program
    {
        //string colour = "black";
        //string model="Bmw"

        static void Main(string[] args)
        {
            cars carspareparts = new cars();
            carspareparts.spareparts();
            //Program obj1 = new Program();
            //Console.WriteLine(obj1.colour);
        }
    }
}
