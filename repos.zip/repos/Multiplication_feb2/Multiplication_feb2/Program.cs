﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplication_feb2
{
    class Program
    {
        static void Main(string[] args)
        {
            int firstNum, secondNum, res;
            Console.WriteLine("please enter the two numbers");
            firstNum = Convert.ToInt32(Console.ReadLine());
            secondNum = Convert.ToInt32(Console.ReadLine());
            res = firstNum * secondNum;
            Console.WriteLine(res);
                
        }
    }
}
