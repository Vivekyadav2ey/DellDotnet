﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructoroverloading_feb3
{
    class ADD
    {
        int x, y;
        double f;
        string s;
        public ADD (int a ,double b )
        {
            x = a;
            f = b;
        }
        public ADD (int a,string b)
        {
            y = a;
            s = b;
        }
        public void show()
        {
            Console.WriteLine("Please add the two number x+y" + x + y);
        }
        public void shows()
        {
            Console.WriteLine("Add the string with the number" + s + x);
        }
        static void Main(string[] args)
        {

            ADD AD1 = new ADD(5, 7);
            AD1.show();
            ADD AD2 = new ADD(2,"ROLLNO");
            AD2.shows();

        }
    }
}
