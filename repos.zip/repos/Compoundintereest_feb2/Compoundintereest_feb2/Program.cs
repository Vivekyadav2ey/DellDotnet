﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compoundintereest_feb2
{
    class Program
    {
        static void Main(string[] args)
        {
            float comp;
            int p, r, day,year,month,n;
            Console.WriteLine("Please enter the principle ,rate");
            Console.WriteLine("Date");
            p = Convert.ToInt32(Console.ReadLine());
            r = Convert.ToInt32(Console.ReadLine());

            //day= Convert.ToInt32(Console.ReadLine());
           // year= Convert.ToInt32(Console.ReadLine());
            //month= Convert.ToInt32(Console.ReadLine());

            

        }
    }
}
