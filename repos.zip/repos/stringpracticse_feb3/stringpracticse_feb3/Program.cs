﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringpracticse_feb3
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = " hello";
            string str1 = "world";
            Console.WriteLine(str.Substring(3,2));
            Console.WriteLine(str1.Substring(2, 3));
            Console.WriteLine(str1.CompareTo(str));
            Console.WriteLine(str.Concat(str1));
            Console.WriteLine(str.Length);
            Console.WriteLine(str1.Length);
            Console.WriteLine(str.IndexOf('o'));
            Console.WriteLine(str1.IndexOf('r'));
            Console.WriteLine(str.LastIndexOf('o'));
            Console.WriteLine(str1.LastIndexOf('o'));
            Console.WriteLine(str.Trim());
            Console.WriteLine(str.ToUpper());
            Console.WriteLine(str.ToLower());
            Console.WriteLine(str.Replace('h','w'));
            string p;
            p = str.Split();
            Console.WriteLine(p);



        }
    }
}
