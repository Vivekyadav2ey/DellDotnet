﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classinheritence_feb2
{
    //making parent class
    class school
    {
        protected void teachers()
        {
            Console.WriteLine("Teachers name");
        }
    }
    class section : school
    {
        public void sections()
        {
            Console.WriteLine("please see the sections");
        }
    }
    class tution : section
    {
        private void students()
        {
            Console.WriteLine("pleasee see the students");
        }
    }//but protected can be accesed through derived object
        

    class Program
    {
        static void Main(string[] args)
        {
            tution teachersname = new tution();
            teachersname.students();
        }
    }
}
