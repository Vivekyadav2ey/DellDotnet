﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY1
{
    class Program
    {
        static void Main(string[] args)
        {
            int firstNum, secondNum,sum;
            Console.WriteLine("Enter the two number");
            firstNum = Convert.ToInt32(Console.ReadLine());
            secondNum = Convert.ToInt32(Console.ReadLine());
            sum = firstNum + secondNum;
            Console.WriteLine(sum);



            
        }
    }
}
