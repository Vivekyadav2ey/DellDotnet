﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_feb3
{
    class Program
    {
        
      
           public string size;
       
    public Program()
    {
        size = " 32";
    }


   
        static void Main(string[] args)
        {
            Program callsize = new Program();
            Console.WriteLine(callsize.size);
        }
    }
}
