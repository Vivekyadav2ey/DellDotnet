﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classexample_feb2
{
    class Program
    {
        static void Main(string[] args)
        {
            class callingobject
        {
            string colour = "Black";
        }
        static void Main(string[] args)
        {
            callingobject obj1 = new callingobject();
            Console.WriteLine(obj1)
        }
        }
    }
}
